<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\employee;
use Illuminate\Support\Facades\DB;

class employeeController extends Controller
{
    //view employees table
    public function viewEmployees() {

        $employee = employee::all();
        return view('employeeView',compact('employee'));
    }
    //view insert form
    public function viewForm() {
        return view('insertData');
    }
    //insert employee
    public function insertData(Request $req) {
        $employee_obj = new employee;
        $employee_obj->firstName=$req->fname;
        $employee_obj->lastName=$req->lname;
        $employee_obj->st_email=$req->email;
        $employee_obj->phoneNumber=$req->phoneNumber;
        $employee_obj->salary=$req->salary;
        $employee_obj->save();

        $employee=employee::all();
        return view('employeeView',compact('employee'));
        

    }
    //For update form 
    public function updateViewForm(Request $req) {

        $employee=DB::table('employees')->where('id',$req->id)->first();

        return view('updateView',compact('employee'));
        

    }
    public function uploadimage()
    {
        return view("uploadImg");
    }

    public function upload(Request $req) {
        $imageName= random_int(100,1000) . "." . $req->img_name->extension();
        
        dd($imageName);
        $req->img_name->move(public_path('images',$imageName));
    }

    public function deleteImg() {
        unlink('images/390.jpg');
        return view('uploadImg');
    }
    //update employee
    public function updateDataCon(Request $req) {

        $employee_obj=employee::find($req->id);
        $employee_obj->firstName=$req->fname;
        $employee_obj->lastName=$req->lname;
        $employee_obj->st_email=$req->email;
        $employee_obj->phoneNumber=$req->phoneNumber;
        $employee_obj->Salary=$req->salary;
        $employee_obj->save();


        $employee=employee::all();
        return view('employeeView',compact('employee'));
    }

    //delete employee
    public function deleteData(Request $req) {
        $employee_obj=DB::table('employees')->where('id',$req->id)->delete();

        $employee=employee::all();
        return view('employeeView',compact('employee'));

    }
}
