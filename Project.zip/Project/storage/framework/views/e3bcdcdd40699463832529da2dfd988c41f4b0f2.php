<!DOCTYPE html>
<html>
<body>
<a href="/deleteImg"><button >Delete</button></a>
<form action="upload" method="post" enctype="multipart/form-data">
  Select image to upload:
  <?php echo csrf_field(); ?>
  <input type="file" name="img_name" id="img_name">
  <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html><?php /**PATH C:\Users\Umair\Desktop\laravel\WebPhase3\phase3\resources\views/uploadImg.blade.php ENDPATH**/ ?>