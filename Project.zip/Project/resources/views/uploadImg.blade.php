<!DOCTYPE html>
<html>
<body>
<a href="/deleteImg"><button >Delete</button></a>
<form action="upload" method="post" enctype="multipart/form-data">
  Select image to upload:
  @csrf
  <input type="file" name="img_name" id="img_name">
  <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html>