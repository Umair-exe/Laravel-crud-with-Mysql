<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
    .trow:hover {
        background-color: whitesmoke;
        color: black;
    }
    </style>
</head>

<body>

    <div class="container mt-3">
        <h2 style="text-align: center; color:#3d3d3d;font-weight:bold;">Laravel Crud</h2>
        <a class="btn btn-primary  " href="/insert">Add New Employee</a>
        <a style="float: right;" class="btn btn-primary " href="/">Home</a>

           <table class="table mt-3" >
            <thead class="thead-dark">
                <tr >
                    <th>EmployeeId</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Salary</th>
                    <th>Action</th>
                </tr>
                @foreach ($employee as $emp)
                <tr class="trow">
                    <td>{{$emp->id}}</td>
                    <td>{{$emp->firstName}}</td>
                    <td>{{$emp->lastName}}</td>
                    <td>{{$emp->st_email}}</td>
                    <td>{{$emp->phoneNumber}}</td>
                    <td>{{$emp->salary}}</td>
                    <td><a style="color: white;" class="btn btn-warning" href="/update?id={{$emp->id}}">Edit</a> | <a class="btn btn-danger" href="/delete?id={{$emp->id}}">Delete</a> </td>
                </tr>
                @endforeach
                </tbody>
        </table>
    </div>

</body>

</html>