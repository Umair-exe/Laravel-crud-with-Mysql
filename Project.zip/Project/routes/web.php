<?php

use App\Http\Controllers\employeeController;
use App\Models\employee;
use Illuminate\Support\Facades\Route;
use PhpParser\Node\Expr\FuncCall;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//default route
Route::get('/',[App\Http\Controllers\employeeController::class,'viewEmployees']);


//View Route
Route::get('/insert',[App\Http\Controllers\employeeController::class,'viewForm']);

//Insert Form Route
Route::post('/insertD',[App\Http\Controllers\employeeController::class,'insertData']);

//Delete route
Route::get('/delete',[\App\Http\Controllers\employeeController::class,'deleteData']);

//Update View Route
Route::get('/update',[\App\Http\Controllers\employeeController::class,'updateViewForm']);

//Update From Route
Route::post('/updateData',[\App\Http\Controllers\employeeController::class,'updateDataCon']);

Route::get('/uploadimage',[\App\Http\Controllers\employeeController::class,'uploadimage']);

Route::post('/upload',[\App\Http\Controllers\employeeController::class,'upload']);
Route::get('/deleteImg',[\App\Http\Controllers\employeeController::class,'deleteImg']);
